define(['jquery', 'scripts/stage', 'scripts/dashboards/dashboard'], function ($) {
    return {
        run: function () {
            //设置鼠标滑轮缩放画布
            // (function () {
            //     var zoom = parseInt($('.canvas-wrapper').css('zoom') || 1, 10),
            //         max = 3,
            //         min = 1;

            //     $('.canvas').on('mousewheel', function (e) {
            //         if ((zoom < max && e.deltaY < 0) || (zoom > 1 && e.deltaY > 0)) {
            //             zoom = zoom * (e.deltaY < 0 ? 1.05 : 0.95);
            //             zoom = zoom > 3 ? 3 : (zoom <= 1 ? 1 : zoom);
            //             $('.canvas-wrapper').css('zoom', zoom);
            //         }
            //     });
            // })();
            (function () {
                var $active = null;
                $('.thumb-list').on('click', '.item', function (e) {
                    $active && $active.removeClass('item-active');
                    $(this).addClass('item-active');
                    $active = $(this);
                });
            })();

            $('.stage').stage();

            $('.dashboard').dashboard()
                .on('dashboardpreview', function (e, animate) {
                    var selections = $('.stage').stage('getSelection');
                    $.each(selections, function (i, $control) {
                        $control.addClass('animated ' + animate.name);
                        $control.one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', (function (_control, animateName) {
                            return function () {
                                _control.removeClass('animated ' + animateName);
                            };
                        })($control, animate.name));
                    });
                });;

            // var DASHBOARD_MAP = {
            //     'control-animation': [
            //         {
            //             label: "控件出现",
            //             deps: ["text!templates/control-animation-entrance.html"]
            //         },
            //         {
            //             label: "效果",
            //             deps: ["text!templates/control-animation-effect.html"]
            //         },
            //         {
            //             label: "控件消失",
            //             deps: ["text!templates/control-animation-exit.html"]
            //         }                  
            //     ]
            // };

            // $('.dashboard').on('click', '.tabs li', function (e) {
            //     console.log(e.target, this, e.delegateTarget);
            //     var current = $(e.delegateTarget).data('type');
            //     var i = parseInt($(this).data('index'), 10);
            //     require(current[i].deps, function (tpl) {
            //         $('.dashboard .panel').html(tpl);
            //     });
            // });

            // var current = DASHBOARD_MAP['control-animation'];
            // if (current) {
            //     var tabs = current.map(function (tab, i) {
            //         return '<li data-index="' + i + '">' + tab.label + '</li>';
            //     });
            //     $('.dashboard').data('type', current);
            //     $('.dashboard .tabs').html(tabs.join(''));
            // }

            // $('.dashboard')
            //     .animatedashboard()
                
        }
    };
});